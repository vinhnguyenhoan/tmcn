<?php
/**
 * Single page template
 *
 * Template Name: Blank
 *
 * @package wpv
 * @subpackage health-center
 */

get_template_part('page');