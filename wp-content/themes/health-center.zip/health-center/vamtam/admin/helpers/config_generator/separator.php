<div class="config-separator <?php if(isset($class)) echo $class ?>" data-tab-class="<?php if(isset($tab_class)) echo esc_attr($tab_class) ?>">
	<?php echo $name ?>
</div>
